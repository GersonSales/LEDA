package main.java.adt.linkedList;

public class DoubleLinkedListImpl<T> extends SingleLinkedListImpl<T>
        implements DoubleLinkedList<T> {

    @Override
    public void insertFirst(T element) {
        // TODO Auto-generated method stub

    }

    @Override
    public void removeFirst() {
        // TODO Auto-generated method stub

    }

    @Override
    public void removeLast() {
        // TODO Auto-generated method stub

    }

}
