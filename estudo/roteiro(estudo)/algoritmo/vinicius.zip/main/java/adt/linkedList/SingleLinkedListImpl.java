package main.java.adt.linkedList;

public class SingleLinkedListImpl<T> implements LinkedList<T> {


    public SingleLinkedListImpl() {
        this.elements = 0;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public T search(T element) {
        return null;
    }

    @Override
    public void insert(T element) {
    }

    @Override
    public void remove(T element) {
    }

    @Override
    public T[] toArray() {
        return null;
    }

}
