package main.java.adt.linkedList;

public class DoubleLinkedListNode<T> extends SingleLinkedListNode<T> {

    public DoubleLinkedListNode(T value) {
        super(value);
        // TODO Auto-generated constructor stub
    }
	
}
