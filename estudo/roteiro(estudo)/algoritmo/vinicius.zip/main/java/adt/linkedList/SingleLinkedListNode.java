package main.java.adt.linkedList;

public class SingleLinkedListNode<T> {

}
