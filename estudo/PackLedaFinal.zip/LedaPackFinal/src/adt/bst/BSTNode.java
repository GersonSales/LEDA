package adt.bst;

import adt.bt.BTNode;

public class BSTNode<T extends Comparable<T>> extends BTNode<T>{

	public boolean isLeaf() {
		// TODO Auto-generated method stub
		return false;
	}

	
}