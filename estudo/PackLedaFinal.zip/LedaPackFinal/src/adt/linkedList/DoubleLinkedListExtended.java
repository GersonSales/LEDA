package adt.linkedList;

public interface DoubleLinkedListExtended<T> extends DoubleLinkedList<T>{

	void insertionSort();

	void splitAndInvert();

}
